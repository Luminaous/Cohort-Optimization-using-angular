const express = require('express');
const cors = require('cors');
const app = express();

// Allow requests from http://localhost:4200
app.use(cors({
    origin: 'http://localhost:4200',
    credentials: true   // if you need to include cookies in the requests
}));

// Other middleware and routes setup
// You would typically define your routes and other middleware here

// Example route
app.get('/api/data', (req, res) => {
    // Handle GET request logic here
    res.json({ message: 'Hello, World!' });
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
