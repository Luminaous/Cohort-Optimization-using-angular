import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MasterBatchComponent } from './master-batch/master-batch.component';
import { ChildBatchComponent } from './child-batch/child-batch.component';

const routes: Routes = [
  { path: '', component: MasterBatchComponent }, // Default route to MasterBatchComponent
  { path: 'child-batch', component: ChildBatchComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
