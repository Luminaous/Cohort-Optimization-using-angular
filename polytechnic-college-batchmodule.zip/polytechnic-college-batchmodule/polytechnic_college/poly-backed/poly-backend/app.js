// app.js
const express = require('express');
const path = require('path');
const indexRouter = require('./routes/index'); // Assuming your route file is named index.js
const masterRouter = require('./routes/master-settings');
const cors=require('cors');

const app = express();
app.use(cors());

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs'); // Assuming you are using EJS as your view engine

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes setup
app.use('/', indexRouter); // Mount the router at '/'
app.use('/master', masterRouter);

// Error handling middleware
app.use(function(err, req, res, next) {
  // Handle errors here, e.g., render an error page
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: err
  });
});

module.exports = app;
