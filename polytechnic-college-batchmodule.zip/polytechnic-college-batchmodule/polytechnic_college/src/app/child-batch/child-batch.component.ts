import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { from, Observable } from 'rxjs';

@Component({
  selector: 'app-child-batch',
  templateUrl: './child-batch.component.html',
  styleUrls: ['./child-batch.component.css']
})
export class ChildBatchComponent {
  years: number[] = [];
  batchStartYear: number;
  batchEndYear: number;
  batchName: string = '';

  userforms: FormGroup = new FormGroup({
    childProgrammeID:new FormControl(1),
    batchID: new FormControl(null),
    batchStartYear: new FormControl('', Validators.required),
    batchEndYear: new FormControl('', Validators.required),
    batchName: new FormControl(''),
    batchStatus: new FormControl(1)
  });

  constructor(private service: ApiService) {
    this.years = this.generateYears(2000);
    const currentYear = new Date().getFullYear();
    this.batchStartYear = this.years[0];
    this.batchEndYear = currentYear;
    this.updateBatch();
  }

  generateYears(startYear: number): number[] {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let year = startYear; year <= currentYear; year++) {
      years.push(year);
    }
    return years;
  }

  updateBatch() {
    this.batchName = `${this.batchStartYear}-${this.batchEndYear}`;
    this.userforms.patchValue({ batchName: this.batchName });
  }

  onformsubmit() {
    if (this.userforms.valid) {
      this.service.createData(this.userforms.value).subscribe(
        (res: any) => {
          console.log('Create Data Response:', res); // Log the response
          this.userforms.reset(); // Reset the form after successful submission
          this.userforms.get('batchStatus')?.setValue(this.userforms.get('batchStatus')?.value ? 1 : 0);
        },
        (error: any) => {
          console.error('Create Data Error:', error); // Log any errors
          // Implement error handling as needed
        }
      );
    }
  }
}
