import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ApiService } from '../api.service';
import { ChildBatchComponent } from '../child-batch/child-batch.component';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'app-app-grid',
  templateUrl: './app-grid.component.html',
  styleUrls: ['./app-grid.component.css']
})
export class AppGridComponent implements OnInit {

  dataSource: any[] = [];  // Ensure this is initialized as an array

  constructor(
    private _dialog: MatDialog,
    private apiService: ApiService
  ) {}

  ngOnInit(): void {
    this.apiService.getData().subscribe(data => {
      this.dataSource = data;
    });
  }


  openAdd(): void {
    this._dialog.open(ChildBatchComponent, {
      width: '400px'  // Optional: Set dialog width
    }).afterClosed().subscribe(() => {
      this.loadBatches();  // Reload batches after the dialog closes
    });
  }
  loadBatches() {
    throw new Error('Method not implemented.');
  }

  openEdit(item: any): void {
    this._dialog.open(EditComponent, {
      width: '400px',  // Optional: Set dialog width
      data: { item }   // Pass the selected batch to the dialog
    }).afterClosed().subscribe(() => {
      this.loadBatches();  // Reload batches after the dialog closes
    });
  }
}
