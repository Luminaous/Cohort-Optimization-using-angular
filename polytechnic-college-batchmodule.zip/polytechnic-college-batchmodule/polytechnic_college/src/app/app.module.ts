import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatGridListModule } from '@angular/material/grid-list';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { HttpClientModule, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http'; // Import HttpClientModule and provideHttpClient
import { ApiService } from './api.service';
import {MatIconModule} from '@angular/material/icon';

import { MasterBatchComponent } from './master-batch/master-batch.component';
import { ChildBatchComponent } from './child-batch/child-batch.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { AppGridComponent } from './app-grid/app-grid.component';
import { EditComponent } from './edit/edit.component';

@NgModule({
  declarations: [
    AppComponent,
    MasterBatchComponent,
    ChildBatchComponent,
    AppGridComponent,
    EditComponent,
  ],
  imports: [
    BrowserModule,
    MatInputModule,
    AppRoutingModule,
    FormsModule,
    MatGridListModule,
    MatDialogModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonToggleModule,
    MatButtonModule,
    MatSlideToggleModule,
    MatIconModule,
    HttpClientModule // Correctly import HttpClientModule here
  ],
  providers: [
    provideClientHydration(),
    provideHttpClient(withInterceptorsFromDi()), // Use provideHttpClient with interceptors
    provideAnimationsAsync(),
    ApiService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
