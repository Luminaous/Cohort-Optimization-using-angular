import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  [x: string]: any;
  baseUrl = 'http://localhost:3000';

  constructor(private httpClient: HttpClient) { }
  data: any[] = [];
  

  getData(): Observable<any> {
    return this.httpClient.get(`${this.baseUrl}/master/getmaster_batch`)
      .pipe(
        catchError(this.handleError)
      );
  }
  createData(data: any): Observable<any> {
    return this.httpClient.post(`${this.baseUrl}/master/updatemaster_batch`, data)
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Unknown error occurred.';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
}