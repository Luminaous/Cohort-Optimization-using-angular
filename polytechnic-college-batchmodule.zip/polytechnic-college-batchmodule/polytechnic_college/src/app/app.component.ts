import { Component } from '@angular/core';

import { ChildBatchComponent } from './child-batch/child-batch.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'polytechnic_college';
 
}
