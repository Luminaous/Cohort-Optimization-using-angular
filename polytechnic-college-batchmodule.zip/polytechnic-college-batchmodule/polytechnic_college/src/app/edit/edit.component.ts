import { Component } from '@angular/core';

import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrl: './edit.component.css'
})
export class EditComponent {
  years: number[] = [];
  selectedStartYear: number;
  selectedEndYear: number;
  batch: string = '';

  userforms: FormGroup = new FormGroup({
    selectedStartYear: new FormControl('', Validators.required),
    selectedEndYear: new FormControl('', Validators.required),
    batch: new FormControl({ value: '', disabled: false }),
    statusToggle: new FormControl(false)
  });

  constructor(private service: ApiService) {
    this.years = this.generateYears(2000); 
    this.selectedStartYear = this.years[0];
    this.selectedEndYear = this.years[this.years.length - 1]; 
    this.updateBatch(); 
  }

  generateYears(startYear: number): number[] {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let year = startYear; year <= currentYear; year++) {
      years.push(year);
    }
    return years;
  }

  updateBatch() {
    this.batch = `${this.selectedStartYear}-${this.selectedEndYear}`;
    this.userforms.patchValue({ batch: this.batch });
  }

  onformsubmit() {
    if (this.userforms.valid) {
      this.service.createData(this.userforms.getRawValue()).subscribe(
        (res: any) => {
          console.log(res, 'res==>');
          this.userforms.reset();
        },
        (error: any) => {
          console.error(error);
          // Handle the error here
        }
      );
    }
  }
}
