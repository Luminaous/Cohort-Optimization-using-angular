var mysql = require('mysql2');

var connection = mysql.createPool({
    host: 'localhost',
    port: 3308,
    user: 'root',
    password: 'root',
    database: 'polytechnic'
});

module.exports = connection;