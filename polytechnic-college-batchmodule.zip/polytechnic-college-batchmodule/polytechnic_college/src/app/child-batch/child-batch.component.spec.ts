import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildBatchComponent } from './child-batch.component';

describe('ChildBatchComponent', () => {
  let component: ChildBatchComponent;
  let fixture: ComponentFixture<ChildBatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChildBatchComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildBatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
