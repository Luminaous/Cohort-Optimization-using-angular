import { Component } from '@angular/core';

import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import { MatDialog } from '@angular/material/dialog';
import { ChildBatchComponent } from '../child-batch/child-batch.component';

@Component({
  selector: 'app-master-batch',
  templateUrl:'./master-batch.component.html',
  styleUrls: ['./master-batch.component.css'] 
})
export class MasterBatchComponent {
  
  options1: string[] = ['Option 1', 'Option 2', 'Option 3'];
  options2: string[] = ['Option A', 'Option B', 'Option C'];
  options3: string[] = ['Option 4', 'Option 5', 'Option 6'];

  selectedOption1!: string;
  selectedOption2!: string;
  selectedOption3!: string;
  constructor(private _dialog:MatDialog){}
    openAdd(){
      this._dialog.open(ChildBatchComponent);
    }

  

}
